local-kit
========
Thanks for your purchase (demo). This is a placeholder archive used in a Kitship portfolio-sample demo to show real end-to-end automated delivery — pick a product, "pay", and the file downloads immediately with no manual step.
